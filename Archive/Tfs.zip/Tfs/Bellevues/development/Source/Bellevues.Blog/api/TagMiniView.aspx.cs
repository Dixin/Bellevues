﻿namespace Api
{
    using System.Web.UI;

    /// <summary>
    /// The tag mini view.
    /// </summary>
    public partial class TagMiniView : Page
    {
    }
}